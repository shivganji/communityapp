export interface CommunityMeetings {
    mom:string;
    momid:number;
    meetingDate:Date;
    communityID:number;
}
