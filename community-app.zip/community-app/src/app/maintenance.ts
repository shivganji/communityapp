export interface Maintenance {
    memberID:number;
    amount:number;
    totalAmount:number;
    date:Date;
}
