export interface Meeting {
    mom:string;
    momid:number;
    meetingDate:Date;
    communityID:number;
}
